(function(e) {
    e.fn.smarticker = function(t) {
        var n;
        var r = e.extend({
            pause: 0,
            maxWidth: 0,
            el: e(this),
            timeouts: [],
            nx: "start",
            newsRollerIndex: 0,
            lastIndex: 99999,
            clearTimeouts: function() {
                for (var t = 0, n = r.timeouts.length; t < n; t++) {
                    clearTimeout(r.timeouts[t])
                }
                r.timeouts = [];
                e("*", r.el).clearQueue()
            }
        }, e.fn.smarticker.defaults, t);
        return this.each(function(t) {
            function m() {
                f = e("li", n);
                n.addClass("smarticker").wrapInner('<div class="smarticker-news"></div>');
                if (r.shuffle) e("li", n).randomize();
                if (g(f, "subcategory").length < 1) r.subcategory = false;
                if (g(f, "category").length < 1) r.category = false;
                if (r.subcategory == true) {
                    i.prependTo(n).addClass("sec1-2");
                    e.each(g(f, "subcategory"), function(e, t) {
                        var n = t;
                        if (t.indexOf(".png") != -1 || t.indexOf(".jpg") != -1 || t.indexOf(".gif") != -1) {
                            n = '<img src="' + r.imagesPath + t + '" />'
                        }
                        i.find("ul").append('<li data-subcategory="' + t + '"><a>' + n + "</a></li>")
                    });
                    if (r.theme == 1 || r.theme == 2) {
                        i.find("ul").wrap('<div class="catlist"></div>');
                        i.append('<span class="right"></span>').prepend('<span class="left"></span>')
                    }
                }
                if (r.category == true && g(f, "category").length > 0) {
                    s.prependTo(n).addClass("sec1-2");
                    e.each(g(f, "category"), function(e, t) {
                        var n = t;
                        if (t.indexOf(".png") != -1 || t.indexOf(".jpg") != -1 || t.indexOf(".gif") != -1) {
                            n = '<img src="' + r.imagesPath + t + '" />'
                        }
                        s.find("ul").append('<li data-category="' + t + '"><a>' + n + "</a></li>")
                    })
                }
                if (r.layout == "horizontal") {
                    if (r.progressbar == true) u.appendTo(e(".smarticker-news", n));
                    if (r.controllerType != false) o.appendTo(n);
                    if (r.category == false) n.addClass("no-category");
                    if (r.subcategory == false) n.addClass("no-subcategory");
                    n.addClass("theme" + r.theme);
                    n.addClass("box size1");
                    n.addClass("c" + r.controllerType);
                    n.addClass("s-" + r.direction);
                    e(".smarticker-news", n).addClass("sec7 newsholder");
                    e(".smarticker-news > ul", n).attr("id", "newsholder").addClass("newsholder");
                    if (r.rounded == true) n.addClass("rounded");
                    if (r.direction == "rtl") n.addClass("rtl");
                    if (r.border == true) n.addClass("border");
                    if (r.shadow == true) n.addClass("shadow");
                    if (r.googleFont == true) n.addClass("googlefont");
                    if (r.category == false || r.subcategory == false) {
                        e(".smarticker-news", n).removeClass("sec7").addClass("sec10")
                    }
                    if (r.category == false && r.subcategory == false && r.titlesection == true) {
                        e(".smarticker-news", n).removeClass("sec7").addClass("sec10");
                        a.prependTo(n).html(r.title)
                    }
                    w();
                    e(".next-news", n).on("click", function() {
                        if (f.length < 2) return false;
                        r.pause = 1;
                        r.nx = "next";
                        r.clearTimeouts();
                        w();
                        if (!e(".pause-news").hasClass("play-news")) r.pause = 0
                    });
                    e(".prev-news", n).on("click", function() {
                        if (f.length < 2) return false;
                        r.pause = 1;
                        r.nx = "prev";
                        r.clearTimeouts();
                        w();
                        r.nx = "next";
                        if (!e(".pause-news").hasClass("play-news")) r.pause = 0
                    });
                    e(".pause-news", n).on("click", function() {
                        if (f.length < 2) return false;
                        if (e(this).hasClass("play-news")) {
                            r.pause = 0;
                            w();
                            e(this).removeClass("play-news").text("Pause")
                        } else {
                            r.clearTimeouts();
                            r.pause = 1;
                            e(this).addClass("play-news").text("Play")
                        }
                    })
                }
                if (r.layout == "vertical") {
                    N("Excuse me! Vertical layout is not available in this version, Please use Horizontal layout!")
                } else {
                    N("Layout type not valid! It must be Vertical Or Horizontal")
                }
            }

            function g(t, n) {
                var r = [];
                e.each(t, function(t, i) {
                    if (e.inArray(e(i).data(n), r) == -1 && e(i).data(n) != undefined) r.push(e(i).data(n))
                });
                return y(r)
            }

            function y(e) {
                for (var t, n, r = e.length; r; t = parseInt(Math.random() * r), n = e[--r], e[r] = e[t], e[t] = n);
                return e
            }

            function b() {
                if (f.length < 2) return false;
                if (r.nx != "start") {
                    r.lastIndex = r.newsRollerIndex
                }
                if (!r.nx || r.nx == "next" || r.nx == "start") {
                    if (r.nx != "start") r.newsRollerIndex++;
                    if (r.newsRollerIndex == e(".newsholder", n).find("li").length) r.newsRollerIndex = 0;
                    r.nx = "next"
                }
                if (r.nx && r.nx == "prev") {
                    r.newsRollerIndex--;
                    if (r.newsRollerIndex == -1) r.newsRollerIndex = e(".newsholder", n).find("li").length - 1
                }
            }

            function w() {
                b();
                r.clearTimeouts();
                if (r.category == false || e(".smarticker-news ul li", n).eq(r.lastIndex).data("category") == e(".smarticker-news ul li", n).eq(r.newsRollerIndex).data("category")) {
                    E()
                } else {
                    e(".active-ag", n).removeClass("active-ag");
                    var t = e(".newsholder li", n).eq(r.newsRollerIndex).data("category");
                    t = e(".smarticker-category ul li", n).index(e('.smarticker-category ul li[data-category="' + t + '"]', n));
                    e(".smarticker-category ul li", n).eq(t).addClass("active-ag");
                    t = e(".active-ag", n);
                    e(".smarticker-category", n).animate({
                        scrollTop: t.offset().top - t.parent().offset().top + t.parent().scrollTop()
                    }, r.speed - r.speed / 2.5, function() {
                        if (r.subcategory != false) {
                            E()
                        } else {
                            S()
                        }
                        var t = e(".newsholder", n).find("li").eq(r.newsRollerIndex).data("color");
                        if (t != undefined && r.catcolor != false) {
                            e(".active-ag a", n).stop().animate({
                                color: "#" + t
                            }, r.speed - r.speed / 2.5)
                        } else e(".active-ag a", n).stop().animate({
                            color: "#999"
                        }, r.speed - r.speed / 2.5)
                    })
                }
            }

            function E() {
                if (r.subcategory == false || e(".smarticker-news ul li", n).eq(r.lastIndex).data("subcategory") == e(".smarticker-news ul li", n).eq(r.newsRollerIndex).data("subcategory")) {
                    N("Last index subcategory: " + r.lastIndex + "=" + e(".smarticker-news ul li", n).eq(r.lastIndex).data("subcategory"));
                    N("This subcategory: " + r.newsRollerIndex + "=" + e(".smarticker-news ul li", n).eq(r.newsRollerIndex).data("subcategory"));
                    if (e(".smarticker-news ul li", n).eq(r.newsRollerIndex).data("color") == e(".smarticker-news ul li", n).eq(r.lastIndex).data("color")) {
                        S();
                        return false
                    }
                }
                e(".active-cat", n).removeClass("active-cat");
                var t = e(".newsholder li", n).eq(r.newsRollerIndex).data("subcategory");
                t = e(".smarticker-cats li", n).index(e('.smarticker-cats li[data-subcategory="' + t + '"]', n));
                e(".smarticker-cats ul li", n).eq(t).addClass("active-cat");
                t = e(".active-cat", n);
                var i = t.parent();
                if (e(".catlist", n).length > 0) i = e(".catlist", n);
                else i = e(".smarticker-cats", n);
                i.animate({
                    scrollTop: Math.max(t.offset().top - i.offset().top + i.scrollTop(), 0)
                }, r.speed - r.speed / 2.5, S);
                var s = e(".newsholder", n).find("li").eq(r.newsRollerIndex).data("color");
                if (s != undefined && r.subcatcolor != false) {
                    e(".smarticker-cats li", n).animate({
                        backgroundColor: "#" + s
                    }, r.speed - r.speed / 2.5)
                } else e(".smarticker-cats li", n).animate({
                    backgroundColor: "#c3c3c3"
                }, r.speed - r.speed / 2.5)
            }

            function S() {
                e(".newsholder", n).css({
                    display: "block",
                    height: "100%"
                });
                u.css("width", "100%").animate({
                    width: 0
                }, r.pausetime);
                if (r.animation == "default") {
                    if (e(".activeRollerItem", n).length > 0) {
                        var t = e(".activeRollerItem", n);
                        t.animate({
                            top: -25,
                            opacity: 0
                        }, r.speed - r.speed / 1.2, function() {
                            t.css("display", "none")
                        }).removeClass("activeRollerItem")
                    }
                    var i = e(".newsholder", n).find("li").eq(r.newsRollerIndex).addClass("activeRollerItem");
                    i.css({
                        top: "25px",
                        display: "block"
                    }).animate({
                        opacity: 1,
                        top: 0
                    }, r.speed - r.speed / 2.5, function() {
                        x()
                    })
                }
                if (r.animation == "slide") {
                    if (r.direction == "ltr") {
                        if (e(".activeRollerItem", n).length > 0) {
                            t = e(".activeRollerItem", n);
                            t.animate({
                                left: 250,
                                opacity: 0
                            }, r.speed - r.speed / 1.5, function() {
                                t.css("display", "none")
                            }).removeClass("activeRollerItem")
                        }
                        var i = e(".newsholder li", n).eq(r.newsRollerIndex).addClass("activeRollerItem");
                        i.css({
                            left: "-150px",
                            display: "block",
                            opacity: "1"
                        }).animate({
                            opacity: 1,
                            left: 10
                        }, r.speed - r.speed / 3, function() {
                            x()
                        })
                    } else {
                        if (e(".activeRollerItem", n).length > 0) {
                            t = e(".activeRollerItem", n);
                            t.animate({
                                right: 250,
                                opacity: 0
                            }, r.speed - r.speed / 1.5, function() {
                                t.css("display", "none")
                            }).removeClass("activeRollerItem")
                        }
                        var i = e(".newsholder li", n).eq(r.newsRollerIndex).addClass("activeRollerItem");
                        i.css({
                            right: "-150px",
                            display: "block",
                            opacity: "1"
                        }).animate({
                            opacity: 1,
                            right: 10
                        }, r.speed - r.speed / 3, function() {
                            x()
                        })
                    }
                }
                if (r.animation == "fade") {
                    if (e(".activeRollerItem", n).length > 0) {
                        t = e(".activeRollerItem", n);
                        t.fadeOut(r.speed / 2, function() {
                            t.removeClass("activeRollerItem")
                        })
                    }
                    var i = e(".newsholder li", n).eq(r.newsRollerIndex).addClass("activeRollerItem");
                    i.css({
                        top: "0",
                        display: "none"
                    }).fadeIn(r.speed / 2, function() {
                        x()
                    })
                }
                if (r.animation == "typing") {
                    if (e(".activeRollerItem", n).length > 0) {
                        t = e(".activeRollerItem", n);
                        var s = e('<div class="hider"></div>');
                        var o = "left";
                        if (r.direction == "rtl") o = "right";
                        s.prependTo(e(".smarticker-news", n)).css({
                            width: "0px",
                            dir: "0px",
                            height: "100%",
                            position: "absolute",
                            "background-color": n.css("background-color"),
                            "z-index": "2"
                        });
                        s.animate({
                            width: t.width() + 30
                        }, r.speed, function() {
                            t.fadeOut(100, function() {
                                t.css("opacity", "0").removeClass("activeRollerItem");
                                s.fadeOut(100, function() {
                                    var t = e(".newsholder li", n).eq(r.newsRollerIndex).addClass("activeRollerItem").css({
                                        display: "block",
                                        opacity: "1"
                                    });
                                    s.remove();
                                    var i = e('<div class="cover"><div class="flasher">_</div></div>');
                                    i.prependTo(e(".smarticker-news", n));
                                    i.css({
                                        "background-color": n.css("background-color")
                                    });
                                    if (r.direction == "ltr") {
                                        i.animate({
                                            left: t.width() + 30
                                        }, t.width() * 8, function() {
                                            i.remove();
                                            x()
                                        })
                                    } else {
                                        i.animate({
                                            right: t.width() + 30
                                        }, t.width() * 8, function() {
                                            i.remove();
                                            x()
                                        })
                                    }
                                })
                            })
                        })
                    } else {
                        var i = e(".newsholder li", n).eq(r.newsRollerIndex).addClass("activeRollerItem").css({
                            display: "block",
                            opacity: "1"
                        });
                        var a = e('<div class="cover"><div class="flasher">_</div></div>');
                        a.prependTo(e(".smarticker-news", n));
                        a.css({
                            "background-color": n.css("background-color")
                        });
                        if (r.direction == "ltr") {
                            a.animate({
                                left: i.width() + 30
                            }, i.width() * 8, function() {
                                a.remove();
                                if (r.pause == 0) {
                                    x()
                                }
                            })
                        } else {
                            a.animate({
                                right: i.width() + 30
                            }, i.width() * 8, function() {
                                a.remove();
                                if (r.pause == 0) {
                                    x()
                                }
                            })
                        }
                    }
                }
            }

            function x() {
                r.maxWidth = 0;
                r.maxWidth = n.width();
                r.maxWidth = r.maxWidth - e(".smarticker-cats", n).width();
                r.maxWidth = r.maxWidth - e(".smarticker-category", n).width();
                if (r.smartController != false) r.maxWidth = r.maxWidth - e(".smart-controller", n).width();
                N("element: " + e(".activeRollerItem", n).width());
                N("max: " + r.maxWidth);
                if (e(".activeRollerItem", n).width() > r.maxWidth) {
                    r.maxWidth = e(".activeRollerItem", n).width() - r.maxWidth + 10;
                    e(".activeRollerItem", n).css("display", "block");
                    if (r.direction == "rtl") {
                        e(".activeRollerItem", n).css("left", "auto").animate({
                            right: 10
                        }, 250).delay(1e3).animate({
                            right: -r.maxWidth
                        }, r.maxWidth * 30, function() {
                            e(".activeRollerItem", n).delay(1e3).animate({
                                right: 10
                            }, 300, function() {
                                if (f.length < 2) return false;
                                T()
                            })
                        })
                    } else {
                        e(".activeRollerItem", n).animate({
                            left: 10
                        }, 250).delay(1e3).animate({
                            left: -r.maxWidth
                        }, r.maxWidth * 30, function() {
                            e(".activeRollerItem", n).delay(1e3).animate({
                                left: 10
                            }, 300, function() {
                                if (f.length < 2) return false;
                                T()
                            })
                        })
                    }
                } else {
                    if (f.length < 2) return false;
                    T()
                }
            }

            function T() {
                if (r.pause != 1) {
                    r.timeouts.push(setTimeout(w, r.pausetime))
                }
            }

            function N(e) {
                if (console.log && r.developerMode == true) {
                    console.log(e)
                }
            }
            var n = e(this);
            var i = e('<div class="smarticker-cats"><ul></ul></div>');
            var s = e('<div class="smarticker-category"><ul></ul></div>');
            r.newsRollerIndex = r.startindex;
            var o = e('<div class="smart-controller"><span class="prev-news">Previous</span><span class="pause-news">Pause</span><span class="next-news">Next</span></div>').css("background", n.css("background"));
            var u = e('<div class="progress-bar"></div>');
            var a = e('<div class="sec1-2 tickertitle"></div>');
            var f = e("li", n);
            e("li", n).css("display", "none");
            if (e.trim(r.rssFeed) != "") {
                n.append('<div class="loading" Style="text-align:center;color:#666;font-size:12px">Loading Rss feed, Please wait ...</div>');
                var l = r.rssFeed.split(",");
                var c = [];
                var h = [];
                var p = [];
                if (r.rssCats) h = r.rssCats.split(",");
                if (r.rssSources) c = r.rssSources.split(",");
                if (r.rssColors) p = r.rssColors.split(",");
                if (r.imagesPath[r.imagesPath.length - 1] != "/" && r.imagesPath != "") r.imagesPath = r.imagesPath + "/";
                var d = 0;

                function v() {
                    var t = e.trim(l[d]);
                    if (r.category != false) {
                        if (c[d] != undefined) {
                            c[d] = 'data-category="' + c[d] + '"'
                        } else {
                            c[d] = 'data-category="Rss"'
                        }
                    } else {
                        c[d] = ""
                    }
                    if (r.subcategory != false) {
                        if (h[d] != undefined) {
                            h[d] = 'data-subcategory="' + h[d] + '"'
                        } else {
                            h[d] = 'data-subcategory="Feed"'
                        }
                    } else {
                        h[d] = ""
                    }
                    if (p[d] != undefined) {
                        p[d] = 'data-color="' + p[d] + '"'
                    } else {
                        p[d] = 'data-color="c3c3c3"'
                    }
                    var i = n;
                    if (n.find("ul").length > 0) i = n.find("ul");
                    if (n.find("ul").length == 0) {
                        i.append("<ul></ul>");
                        i = n.find("ul")
                    }
                    if (r.feedLoader == "") r.googleApi = true;
                    n.addClass("google-api");
                    var s = window.location.protocol + "//ajax.googleapis.com/ajax/services/feed/load?v=1.0&num=" + r.rssLimit + "&callback=?&q=" + encodeURIComponent(t);
                    var o;
                    if (!r.googleApi || r.feedLoader != "") {
                        n.removeClass("google-api").addClass("feed-loader");
                        s = r.feedLoader;
                        o = {
                            siteurl: t,
                            limit: r.rssLimit
                        }
                    }
                    e.ajax({
                        type: "GET",
                        url: s,
                        data: o,
                        dataType: "json",
                        beforeSend: function() {
                            e(".loading", n).text("Loading feed " + (d + 1) + " of " + l.length)
                        },
                        error: function() {
                            N("Unable to load feed, Incorrect path or invalid feed")
                        },
                        success: function(t) {
                            var i;
                            if (!r.googleApi || r.feedLoader != "") i = t.item;
                            else i = t.responseData.feed.entries;
                            e.each(i, function(t, s) {
                                var s = e(this)[0];
                                var o = e('<li style="display:none" ' + p[d] + " " + h[d] + " " + c[d] + '><a target="' + r.linkTarget + '" href="' + s.link + '"></a></li>');
                                o.find("a").html(s.title);
                                var u = n;
                                var a;
                                if (s.pubdate != undefined || s.pubdate != "" || s.pubdate != NaN) a = s.pubdate;
                                a = new Date(a);
                                var f = Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
                                var g = a.getDate() + " " + f[a.getMonth()] + " " + a.getFullYear();
                                if (r.showDate != "" || r.showDate != false && s.pubdate != undefined) e('<span class="item-date">' + g + "</span>").appendTo(o);
                                if (n.find("ul").length > 0) u = n.find("ul");
                                if (r.feedsOrder == "older") o.appendTo(u);
                                else o.prependTo(u);
                                if (t == i.length - 1) {
                                    if (d == l.length - 1) {
                                        e(".loading", n).fadeOut(200, function() {
                                            e(".loading", n).remove()
                                        });
                                        m()
                                    } else {
                                        d++;
                                        v()
                                    }
                                }
                            })
                        }
                    })
                }
                v()
            } else {
                m()
            }
        })
    };
    e.fn.smarticker.defaults = {
        theme: 1,
        direction: "ltr",
        layout: "horizontal",
        animation: "default",
        speed: 1e3,
        startindex: 0,
        pausetime: 3e3,
        rounded: false,
        shadow: false,
        border: false,
        category: true,
        subcategory: true,
        titlesection: false,
        title: "Headlines",
        progressbar: false,
        catcolor: true,
        subcatcolor: true,
        shuffle: false,
        rssFeed: "",
        rssLimit: 10,
        rssCats: "",
        rssSources: "",
        rssColors: "",
        showDate: false,
        googleApi: true,
        feedLoader: "",
        feedsOrder: "older",
        linkTarget: "_blank",
        controllerType: false,
        googleFont: true,
        imagesPath: "",
        developerMode: false
    }
})(jQuery);